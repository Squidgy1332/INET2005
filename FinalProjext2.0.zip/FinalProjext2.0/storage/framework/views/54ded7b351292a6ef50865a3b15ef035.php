<!DOCTYPE html>
<style>
table {
  font-family: Arial, Helvetica, sans-serif;
  border-collapse: collapse;
  width: 50%;
}

td, th {
  border: 1px solid #ddd;
  padding: 8px;
}

tr:nth-child(even){background-color: #f2f2f2;}

tr:hover {background-color: #ddd;}

th {
  padding-top: 12px;
  padding-bottom: 12px;
  text-align: left;
  background-color: #04AA6D;
  color: white;
}
</style>
<a href="<?php echo e(route('create')); ?>"><button>add category</button></a>
<a href="<?php echo e(route('item')); ?>"><button>view items</button></a>
<table>
    <tr>
        <th>Name</th>
        <th>view items</th>
    </tr>

    <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <tr>
        <td><?php echo e($category->name); ?></td>
        <td><a href="<?php echo e(route('edit', ['id' => $category->id])); ?>"><button>edit</button></a></td>
    </tr>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
</table><?php /**PATH C:\Users\liamp\GitHub\INET2005\FinalProjext2.0\resources\views/categories/index.blade.php ENDPATH**/ ?>