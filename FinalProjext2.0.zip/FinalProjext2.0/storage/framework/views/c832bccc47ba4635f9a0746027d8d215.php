<!DOCTYPE html>
<form  method="post" action="<?php echo e(url('/categories/store')); ?>">
    <?php echo csrf_field(); ?>
    <?php echo method_field('PATCH'); ?>
    <label for="category_name">Category Name:</label>
    <input type="text" name="category_name" required>
    <br>
    <input type="submit" value="Create Category">
</form>
<?php $__errorArgs = ["category_name"];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
<?php echo e("category already exists"); ?> 
<?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?><?php /**PATH C:\Users\liamp\GitHub\INET2005\FinalProjext2.0\resources\views/categories/create.blade.php ENDPATH**/ ?>