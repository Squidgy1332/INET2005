<form  method="post" action="<?php echo e(url('/items/update', ['id' => $item->id])); ?>">
    <?php echo csrf_field(); ?>
    <?php echo method_field('PATCH'); ?>
    <label for="item_name">Item Name:</label>
    <input type="text" name="item_name" value="<?php echo e($item->title); ?>" required>
    <br>
    <label for="item_Price">Item Price:</label>
    <input type="text" name="item_Price" value="<?php echo e($item->price); ?>" required>
    <br>
    <label for="item_quantity">Item Quantity:</label>
    <input type="text" name="item_quantity" value="<?php echo e($item->quantity); ?>" required>
    <br>
    <label for="item_SKU">Item SKU:</label>
    <input type="text" name="item_SKU" value="<?php echo e($item->SKU); ?>" required>
    <br>
    <label for="item_description">Item Description:</label>
    <input type="text" name="item_description" value="<?php echo e($item->description); ?>" required>
    <br>
    <label for="item_CID">Category ID:</label>
    <input type="text" name="item_CID" value="<?php echo e($item->category_id); ?>" require>
    <br>
    <img src="<?php echo e(asset('storage/' . $item->Image)); ?>" alt="Image of <?php echo e($item->title); ?>" style="width: 400px">
    <br>
    <label for="item_img">Item Image:</label>
    <input type="file" name="item_img" value="<?php echo e($item->Image); ?>">
    <br>
    <input type="submit" value="Edit Item">
</form>
<?php if($errors->any()): ?>
    <div class="alert alert-danger">
        <ul>
            <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <li><?php echo e($error); ?></li>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </ul>
    </div>
<?php endif; ?><?php /**PATH C:\Users\liamp\GitHub\INET2005\FinalProjext2.0\resources\views/items/itemEdit.blade.php ENDPATH**/ ?>