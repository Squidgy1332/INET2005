<!DOCTYPE html>
<a href="<?php echo e(route('create')); ?>"><button>add category</button></a>

<ul>
    <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <li><?php echo e($category->name); ?></li>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
</ul><?php /**PATH C:\Users\liamp\GitHub\INET2005\FinalProjext2.0\resources\views/index.blade.php ENDPATH**/ ?>