<!DOCTYPE html>
<form  method="post" action="<?php echo e(url('/categories')); ?>">
    <label for="category_name">Category Name:</label>
    <input type="text" name="category_name" required>
    <br>
    <input type="submit" value="Create Category">
</form><?php /**PATH C:\Users\liamp\GitHub\INET2005\FinalProjext2.0\resources\views/categorises/create.blade.php ENDPATH**/ ?>